using car_factory.Car.Type;
namespace car_factory.Car.Cars
{
    public class HatchBack : Car
    {
        public HatchBack()
        {
            Type = CarType.HatchBack;
        }
    }
}