using car_factory.Car.Type;
namespace car_factory.Car.Cars
{
    public class Truck : Car
    {
        public Truck()
        {
            Type = CarType.Truck;
        }
    }
}