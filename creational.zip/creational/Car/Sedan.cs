namespace creational.Car
{
    public class Sedan : Car
    {
        public Sedan()
        {
            Type = CarType.Sedan;
        }
    }
}