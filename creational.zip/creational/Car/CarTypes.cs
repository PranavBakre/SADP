namespace creational.Car
{
    public enum CarType
    {
        Sedan,
        HatchBack,
        SUV,
        Truck,
    }
}