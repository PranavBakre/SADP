using car_factory.Car.Type;
namespace car_factory.Car.Cars
{
    public class Sedan : Car
    {
        public Sedan()
        {
            Type = CarType.Sedan;
        }
    }
}