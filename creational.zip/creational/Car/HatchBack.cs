namespace creational.Car
{
    public class HatchBack : Car
    {
        public HatchBack()
        {
            Type = CarType.HatchBack;
        }
    }
}