namespace creational.Car
{
    public class SUV : Car
    {
        public SUV()
        {
            Type = CarType.SUV;
        }
    }
}