namespace car_factory.Car.Type
{
    public enum CarType
    {
        Sedan,
        HatchBack,
        SUV,
        Truck,
    }
}