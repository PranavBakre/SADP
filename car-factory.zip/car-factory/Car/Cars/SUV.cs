using car_factory.Car.Type;
namespace car_factory.Car.Cars
{
    public class SUV : Car
    {
        public SUV()
        {
            Type = CarType.SUV;
        }
    }
}