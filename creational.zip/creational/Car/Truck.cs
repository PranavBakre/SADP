namespace creational.Car
{
    public class Truck : Car
    {
        public Truck()
        {
            Type = CarType.Truck;
        }
    }
}